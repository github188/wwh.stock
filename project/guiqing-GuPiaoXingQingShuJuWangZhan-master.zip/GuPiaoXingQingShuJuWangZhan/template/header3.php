<link type="css/text" rel="stylesheet" href="css/common.css?v=6a246cd28d218f64530d6e5da58ea0e2">
<link type="css/text" rel="stylesheet" href="css/info.css">
<link type="css/text" rel="stylesheet" href="css/ui.css">
<link type="css/text" rel="stylesheet" href="css/iconfont.css">
<div class="header" id="header">
    <div class="wrap clearBox">
        <div class="logo">
            <a href="/index.php" title="港股美股交流社区"></a>
        </div>
        <div class="mainNav js-mainNav" style="margin-left:187px">
            <a href="/index.php" class="a01 current">首页</a>
            <a href="/shszhq.php?plate=shsz&s=shsz&type=up100&k=hszsA" class="a01 ">行情</a>
            <a href="/info.php" class="a01">资讯</a>
            <a href="/download.php" class="a01">下载</a>
          
            <a href="/about.php" class="a01" type="about">关于</a>
            <span style="display: none" class="floatSpan01" onmouseout="this.className='floatSpan01'" onmouseover="this.className='floatSpan01 floatSpan01Onmouse'">
                <a class="a01" href="javascript:;">发现</a>
                <div class="xlBox01 floatBox02">
                    <div class="alpha001"></div>
                    <i class="i01"></i>
                    <a href="/act">活动</a>
                    <a href="/trade" class="ui-login-link">模拟炒股</a>
                    <a href="/newstock" class="bb0">新股认购</a>
                </div>
            </span>
           
          </div>

        <div class="headerRight01 clearBox">
            <div class="headerSearchFloat">
                <div class="alpha001"></div>
                <i class="i01"></i>
                <div class="headerSearchBar ui-selectbox-wrapper" data-type="combobox" data-hidedoropdown="true" style="z-index: auto;">
                    <i class="iconfont"></i>
                    <input class="inputTxt01 ui-selectbox-input" id="topStockSearch" name="stockCode" type="text" placeholder="输入股票名称、代码、拼音"><span class="ui-selectbox-clearInput row01" title="清除" style="display: none;"><i class="iconfont"></i></span><div class="selectFloatBox ui-selectbox-dropdownArea" style="display: none;"></div>
                    <select class="ui-selectbox-select"></select>
                </div>
            </div>

            <div id="accountHeader" class="clearBox fl" style="display:inline-block;">
                                <span class="txtSpan01">
                    <a href="javascript:void(0)" class="ui-login">登录</a><span class="sLine01">|</span><a href="javascript:void(0)" class="ui-register">注册</a>
                </span>
            </div>
        </div>
    </div>
</div>
<div class="headerGap01"></div>

<script>
$('.mainNav').find('a').click(function(){
    $(this).addClass('current').sublings().removeClass('current');
});

</script>