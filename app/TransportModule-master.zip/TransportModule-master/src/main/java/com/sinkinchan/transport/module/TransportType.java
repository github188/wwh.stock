package com.sinkinchan.transport.module;

/**
 * Created by apple on 2016/10/23.
 */
public enum TransportType {
    login, logout, register, registerSuccess, registerFailed, loginSuccess,
    loginFailed, useFunction, askUseFunction, useFunction_ActiveStock, useFunction_ResearchStock,
    useFunction_QuotaStockType1, useFunction_QuotaStockType2, useFunction_QuotaStockType3, useFunction_QuotaStockType4,
    useFunction_DeathSquadStock
}
