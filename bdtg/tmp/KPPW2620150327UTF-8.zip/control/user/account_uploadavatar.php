<?php defined ( 'IN_KEKE' ) or exit('Access Denied');
$strUserSwf =keke_user_avatar_class::avatar_html($gUid);
