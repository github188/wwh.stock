/**
 * 租户信息处理相关类
 */
package com.baomidou.mybatisplus.plugins.tenancy.handler;
