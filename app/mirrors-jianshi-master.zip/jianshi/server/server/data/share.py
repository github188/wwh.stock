#!/usr/bin/env python
# -*- coding: utf-8 -*-

share_text = "我会化作人间的风雨,陪在你身旁. #简诗,回归文字的本质# "