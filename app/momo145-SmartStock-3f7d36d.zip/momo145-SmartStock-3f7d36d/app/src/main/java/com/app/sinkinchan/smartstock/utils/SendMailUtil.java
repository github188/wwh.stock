package com.app.sinkinchan.smartstock.utils;

/**
 * @author : 陈欣健
 * @describe :
 * @since :2016-12-29 下午4:05
 **/
public class SendMailUtil {


}
