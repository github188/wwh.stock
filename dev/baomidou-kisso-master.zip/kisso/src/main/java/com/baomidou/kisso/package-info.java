/**
 * SSO 配置，票据，辅助组件类
 * <p>
 * <p>
 * kisso = cookie sso，基于 Cookie 的 SSO 中间件，它是一把快速开发 java Web 单点登录系统的瑞士军刀。
 * </p>
 */
package com.baomidou.kisso;