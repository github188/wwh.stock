<?php defined ( 'IN_KEKE' ) or exit('Access Denied');
$do = trim($do);
$view = trim($view);
$gUid = intval($uid);
$op = trim($op);
$gUserInfo = $user_info;
$arrView = array('index','account','message','transaction','shop','collect','focus','prom','finance','added','prom','finance','gz','wk');
if(false === in_array($view,$arrView)){
	$view ='account';
}
$gUid or header ( "location:index.php?do=login" );
$intCountTrends = db_factory::get_count("select count(msg_id) from ".TABLEPRE."witkey_msg where uid<1 and view_status!=1 and type=1 and  to_uid=".intval($gUid));
$intCountNotice = db_factory::get_count("select count(msg_id) from ".TABLEPRE."witkey_msg where uid<1 and view_status!=1 and type=2 and  to_uid=".intval($gUid));
$intCountPrivate = db_factory::get_count("select count(msg_id) from ".TABLEPRE."witkey_msg where to_uid = ".intval($gUid)." and view_status!=1 and uid>0 and msg_status<>2 ");
$strUsersUrl='index.php?do='.$do.'&view='.$view;
$strPageTitle='用户中心';
$arrAuthRecords = kekezu::get_table_data('auth_code,auth_status','witkey_auth_record',"uid=".$gUid,'','','','auth_code');
if(!$op){
	$op = 'index';
}
if(file_exists(S_ROOT.'/control/'.$do.'/'.$view.'_'.$op.'.php') && file_exists(S_ROOT.'/tpl/default/'.$do.'/'.$view.'_'.$op.'.htm')){
	require $do.'/'.$view.'_'.$op.'.php';
	require  $kekezu->_tpl_obj->template($do.'/'.$view.'_'.$op);die();
};
kekezu::show_msg('您访问的页面不存在','index.php?do=user&view=account',null,null,'danger');
