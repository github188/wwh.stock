package com.ijustyce.weekly1601.bean;

/**
 * Created by yangchun on 2017/2/7.
 */

public class AlbumBean {
    public String albumTitle, shareTitle;
}
