<?php
defined ( 'ADMIN_KEKE' ) or exit('Access Denied');
$auth_config=array(
  'auth_code'=>'alipayjs',
  'auth_title' =>'支付宝认证',
  'auth_cash' =>'1-3',
  'auth_day' =>'1-3',
  'auth_expir' => '',
  'auth_dir'=>'alipayjs',
  'auth_small_ico' =>'',
  'auth_big_ico' =>'',
  'auth_desc' =>'支付宝认证',
  'auth_show' =>'0',
  'auth_open' =>'1',
  'update_time' =>'1306142441
  ',
);
?>