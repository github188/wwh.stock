
![kisso图标](http://git.oschina.net/uploads/images/2015/1122/122054_3b6813fa_12260.png "爱心萝卜 kisso")

kisso  =  cookie sso 基于 Cookie 的 SSO 中间件，它是一把快速开发 java Web 登录系统（SSO）的瑞士军刀。


[kisso 帮助文档下载](http://git.oschina.net/baomidou/kisso/attach_files)

[spring boot 演示 demo](https://gitee.com/baomidou/kisso-spring-boot)

[3.7.0 之前版本，实战 DEMO](http://git.oschina.net/juapk/SpringWind)



> 技术讨论 QQ 群 576493122 [（有钱的捧个钱场【点击捐赠】, 没钱的捧个人场）](http://git.oschina.net/uploads/images/2015/1222/211207_0acab44e_12260.png)


# 其他开源项目 | Other Project

- [Mybatis-Plus CRUD 快速开发框架](http://git.oschina.net/baomidou/mybatis-plus)
- [基于Hibernate扩展 Hibernate-Plus](http://git.oschina.net/baomidou/hibernate-plus)

http://baomidou.com/

http://www.oschina.net/p/kisso

[kisso 升级日志](http://git.oschina.net/baomidou/kisso/wikis/kisso---%E5%8D%87%E7%BA%A7%E6%97%A5%E5%BF%97)

[kisso捐赠记录,感谢你们的支持！](http://git.oschina.net/baomidou/kisso/wikis/%E6%8D%90%E8%B5%A0%E8%AE%B0%E5%BD%95)


Maven 坐标
===
```
<dependency>
  <groupId>com.baomidou</groupId>
  <artifactId>kisso</artifactId>
  <version>最新版本 maven 为准</version>
</dependency>
```

捐赠 kisso
====================

![捐赠 kisso](http://git.oschina.net/uploads/images/2015/1222/211207_0acab44e_12260.png "支持一下kisso")

- 欢迎提出更好的意见，帮助完善 KISSO 

copyright
====================
Apache License, Version 2.0

关注我
====================
![程序员日记](http://git.oschina.net/uploads/images/2016/0121/093728_1bc1658f_12260.png "程序员日记")