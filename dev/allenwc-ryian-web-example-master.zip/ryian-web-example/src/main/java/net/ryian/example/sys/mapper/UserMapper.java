package net.ryian.example.sys.mapper;

import net.ryian.example.sys.domain.User;
import tk.mybatis.mapper.common.Mapper;

/**
 * Created by allenwc on 15/9/10.
 */
public interface UserMapper extends Mapper<User>{
}
