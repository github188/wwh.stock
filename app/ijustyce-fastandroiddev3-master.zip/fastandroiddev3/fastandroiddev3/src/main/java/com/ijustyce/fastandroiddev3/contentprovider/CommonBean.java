package com.ijustyce.fastandroiddev3.contentprovider;

/**
 * Created by yc on 17-4-23.
 */

public class CommonBean {
    public String key, value, userId;
}
