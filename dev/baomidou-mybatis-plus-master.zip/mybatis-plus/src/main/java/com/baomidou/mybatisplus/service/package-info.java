/**
 * service 超级抽象类
 */
package com.baomidou.mybatisplus.service;
