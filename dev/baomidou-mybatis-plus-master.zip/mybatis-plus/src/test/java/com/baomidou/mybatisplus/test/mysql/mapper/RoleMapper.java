package com.baomidou.mybatisplus.test.mysql.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.mysql.entity.Role;

/**
 * @author junyu
 * @Date 2016-09-09
 */
public interface RoleMapper extends BaseMapper<Role> {

}
