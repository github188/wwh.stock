package net.ryian.commons;

/**
 * 集合工具类，对org.apache.commons.collections.CollectionUtils的扩展
 * @author wangcheng
 *
 */
public class CollectionUtils extends org.apache.commons.collections.CollectionUtils{

}
