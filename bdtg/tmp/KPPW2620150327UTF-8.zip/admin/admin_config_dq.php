<?php	defined ( 'ADMIN_KEKE' ) or exit ( 'Access Denied' );
$objDistrict = keke_table_class::get_instance('witkey_district');
$url = 'index.php?do=config&view=dq';
if($page){
	$page=$_R['page'];
	$url.='&page='.$page;
}else{
	$page=1;
}
$isShop12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='shop12'");
$isClose12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='close12'");
$isTask12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='task12'");
$objDq = keke_table_class::get_instance('witkey_basic_config');
if($_R[op]=='del'){
	$intResult = $objDistrict->del('id',$_R[id]);
	kekezu::admin_show_msg ( $_lang['operate_success'], "index.php?do=config&view=dq&page=".$page, 3, '', 'success' );
}
if($_R[xianshi]==1){
	$isshop12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='shop12'");
	if($isshop12){
		$arrFields=array('v'=>$_R[xianshi]);
		$arrWhere = array('k'=>'shop12');
		$intResult = $objDq->save($arrFields,$arrWhere);
	}else{
		$arrFields=array('v'=>$_R[xianshi],'k'=>'shop12');
		$intResult = $objDq->save($arrFields);
	}
	die;
} 
if($_R[xianshi]==4){
	$isshop12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='shop12'");
	if($isshop12){
		$arrFields=array('v'=>$_R[xianshi]);
		$arrWhere = array('k'=>'shop12');
		$intResult = $objDq->save($arrFields,$arrWhere);
	}else{
		$arrFields=array('v'=>$_R[xianshi],'k'=>'shop12');
		$intResult = $objDq->save($arrFields);
	}
	die;
}
if($_R[xianshi]==2){
	$isclose12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='close12'");
	if($isclose12){
		$arrFields=array('v'=>$_R[xianshi]);
		$arrWhere = array('k'=>'close12');
		$intResult = $objDq->save($arrFields,$arrWhere);
	}else{
		$arrFields=array('v'=>$_R[xianshi],'k'=>'close12');
		$intResult = $objDq->save($arrFields);
	}
	die;
}
if($_R[xianshi]==6){
	$isclose12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='close12'");
	if($isclose12){
		$arrFields=array('v'=>$_R[xianshi]);
		$arrWhere = array('k'=>'close12');
		$intResult = $objDq->save($arrFields,$arrWhere);
	}else{
		$arrFields=array('v'=>$_R[xianshi],'k'=>'close12');
		$intResult = $objDq->save($arrFields);
	}
	die;
}
if($_R[xianshi]==3){
	$istask12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='task12'");
	if($istask12){
		$arrFields=array('v'=>$_R[xianshi]);
		$arrWhere = array('k'=>'task12');
		$intResult = $objDq->save($arrFields,$arrWhere);
	}else{
		$arrFields=array('v'=>$_R[xianshi],'k'=>'task12');
		$intResult = $objDq->save($arrFields);
	}
	die;
}
if($_R[xianshi]==5){
	$istask12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='task12'");
	if($istask12){
		$arrFields=array('v'=>$_R[xianshi]);
		$arrWhere = array('k'=>'task12');
		$intResult = $objDq->save($arrFields,$arrWhere);
	}else{
		$arrFields=array('v'=>$_R[xianshi],'k'=>'task12');
		$intResult = $objDq->save($arrFields);
	}
	die;
}
$one=$objDistrict->get_grid('upid=0', $url,$page,10,' order by id asc','1','ajax_dom');
if($_R['is_submit']==1){
	foreach($_R[id] as $key =>$val){
		$arrFields = array('name'=>$_R[name][$key],'displayorder'=>$_R[displayorder][$key]);
		$arrWhere = array('id'=>$_R[id][$key]);
		$intResult = $objDistrict->save($arrFields,$arrWhere);
	}
		kekezu::admin_show_msg ( "修改成功", "index.php?do=config&view=dq&page=".$page, 2, '', 'success' );
}else{
	require $template_obj->template(ADMIN_DIRECTORY.'/tpl/admin_config_' . $view );
}
