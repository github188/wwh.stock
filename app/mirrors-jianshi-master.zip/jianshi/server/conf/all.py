# Here is all config with lowest priority, can be override by conf/dev & conf/prod
TEST_CONFIG = 'all'

DEBUG = True

# user
AUTH_TOKEN_EXPIRE_TIME = 86400 * 30 * 6

# admin email for error report
ADMIN_EMAILS = ['yinjiesh@126.com', 'panlei106@gmail.com']
