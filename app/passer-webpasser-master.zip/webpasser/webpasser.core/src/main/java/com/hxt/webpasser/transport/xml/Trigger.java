/*
 * 系统名称: 
 * 模块名称: webpasser.core
 * 类 名 称: trigger.java
 *   
 */
package com.hxt.webpasser.transport.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * 功能说明:  <br>
 * 系统版本: v1.0 <br>
 * 作者: hanxuetong <br>
 * ======== ====== ============================================ <br>
 * 
 */
@XStreamAlias("trigger")
public class Trigger  extends ClassHandler {
	
/*	@XStreamAsAttribute
	@XStreamAlias("class")
	private String clazz;

	public String getClazz() {
		return clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}*/
	
	
}
