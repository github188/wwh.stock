/*
 * 系统名称: 
 * 模块名称: webpasser.core
 * 类 名 称: URLPage.java
 *   
 */
package com.hxt.webpasser.spider;
/**
 * 功能说明:  <br>
 * 系统版本: v1.0 <br>
 * 开发人员: hanxuetong <br>
 * 开发时间: 2015-8-14 <br>
 * 审核人员:  <br>
 * 相关文档:  <br>
 * 修改记录:  <br>
 * 修改日期 修改人员 修改说明  <br>
 * ======== ====== ============================================ <br>
 * 
 */
public class URLPage {

	
	
	
}
