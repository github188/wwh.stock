package com.ijustyce.fastandroiddev3.irecyclerview;

import java.util.ArrayList;

/**
 * Created by yangchun on 2016/11/12.
 */

public abstract class IResponseData<T> {

    public abstract ArrayList<T> getList() ;
}