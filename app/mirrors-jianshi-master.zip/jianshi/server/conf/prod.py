# Prod env
TEST_CONFIG = 'prod'

DEBUG = False

# home image_poem fetch time gap
HOME_IMAGE_POEM_FETCH_TIME_GAP = 5*60
