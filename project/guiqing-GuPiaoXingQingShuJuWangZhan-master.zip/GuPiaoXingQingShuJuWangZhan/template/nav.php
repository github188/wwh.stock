     <div class="tabBox02 tabBox02-2">
        <ul>
           <!--<li class="all">
                <a href="hqAll.php?s=all" target="mainFrom"><span>行情总览</span></a>
            </li> -->
            <li class="shsz">
               <a href="shszhq.php?plate=shsz&s=shsz&type=up100&k=hszsA" target="mainFrom"><span>沪深</span></a>
            </li>
            <li class="hkhq">
                <a href="hkhq.php?plate=hkhq&s=hkhq&type=up100&k=hk_c" target="mainFrom"><span>港股</span></a>
            </li>
            <li class="ushq">
                <a href="ushq.php?plate=ushq&s=ushq&type=up100&k=us_a" target="mainFrom"><span>美股</span></a>
            </li>
            <li class="shhkhq">
               <a href="shhkhq.php?plate=ushq&s=shhkhq&k=sh_c" target="mainFrom"><span>沪港通</span></a>
            </li>
        </ul>
    </div>
