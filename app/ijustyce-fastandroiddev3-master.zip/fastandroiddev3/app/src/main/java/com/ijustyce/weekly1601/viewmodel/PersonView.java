package com.ijustyce.weekly1601.viewmodel;

import com.ijustyce.fastandroiddev3.base.BaseViewModel;

/**
 * Created by yangchun on 2016/11/13.
 */

public class PersonView extends BaseViewModel {

    public String headUrl, name, description;
}