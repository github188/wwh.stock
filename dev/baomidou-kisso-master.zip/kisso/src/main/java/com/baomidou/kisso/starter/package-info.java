/**
 * Spring boot starter
 */
package com.baomidou.kisso.starter;
