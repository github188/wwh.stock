package net.ryian.commons;

/**
 * Object工具类，对org.apache.commons.lang3.ObjectUtils的扩展
 * @author wangcheng
 *
 */
public class ObjectUtils extends org.apache.commons.lang3.ObjectUtils{

}