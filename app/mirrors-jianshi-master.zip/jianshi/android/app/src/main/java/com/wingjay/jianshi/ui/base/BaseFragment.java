/*
 * Created by wingjay on 11/16/16 3:31 PM
 * Copyright (c) 2016.  All rights reserved.
 *
 * Last modified 8/13/16 11:49 PM
 *
 * Reach me: https://github.com/wingjay
 * Email: yinjiesh@126.com
 */

package com.wingjay.jianshi.ui.base;

import android.support.v4.app.Fragment;

/**
 * Created by wingjay on 10/6/15.
 */
public class BaseFragment extends Fragment {
}
