package com.ijustyce.weekly1601.bean;

import com.ijustyce.fastandroiddev3.base.BaseViewModel;

/**
 * Created by yangchun on 2017/2/17.
 */

public class PictureBean extends BaseViewModel {

    public String url;
}
