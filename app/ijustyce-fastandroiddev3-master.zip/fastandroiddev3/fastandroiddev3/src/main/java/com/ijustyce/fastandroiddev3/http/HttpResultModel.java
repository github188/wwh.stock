package com.ijustyce.fastandroiddev3.http;

/**
 * Created by yangchun on 2017/3/10.
 */

public interface HttpResultModel {

    boolean needLogin();
//    boolean isSuccess();
//    boolean getErrorMsg();
//    boolean needReLogin();
}
