package com.ijustyce.weekly1601.bean;

/**
 * Created by yc on 17-4-23.
 */
public class Bean {
    public String city, province, number;
}
