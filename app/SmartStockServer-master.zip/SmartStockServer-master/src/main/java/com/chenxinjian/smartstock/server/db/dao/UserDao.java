package com.chenxinjian.smartstock.server.db.dao;


import com.chenxinjian.smartstock.server.db.base.BaseDao;
import com.sinkinchan.transport.module.UserBean;

public interface UserDao extends BaseDao<UserBean> {

}
