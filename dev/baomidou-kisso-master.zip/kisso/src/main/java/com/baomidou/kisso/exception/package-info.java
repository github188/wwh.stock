/**
 * kisso 异常
 */
package com.baomidou.kisso.exception;