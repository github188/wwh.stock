## 2.1.1
clear database when logging out

## 2.1
- Misc items: login error message; stausbar color; font mechanism; upgrade dialog in home page

## 1.9.1
- bugfix: screen black due to unknown horizonscrollview width in ViewPage
- home image background transparent layer

## 1.9
Preview for v2.0:
- Login & Signup
- Data Sync
- Server infrastructure: logging, error handle
- Share screenshot function
- AliYun server setup
- Jenkins deploy server code
