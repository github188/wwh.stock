package com.ijustyce.fastandroiddev3.event;

import android.view.View;

/**
 * Created by yangchun on 2016/11/12.
 */

public class TitleBarEvent {

    public TitleBarEvent() {
    }

    public void titleBarClick(View view) {

    }

    public void leftTextClick(View view) {

    }

    public void titleTextClick(View view) {

    }

    public void rightTextClick(View view) {

    }

    public void rightIconClick(View view) {

    }
}