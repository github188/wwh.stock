package com.chenxinjian.smartstock.server.cache;


import com.chenxinjian.smartstock.server.cache.base.BaseCacheDao;
import com.sinkinchan.transport.module.UserBean;
import org.springframework.stereotype.Component;

/**
 * Created by apple on 2016/10/23.
 */
@Component()
public class UserCacheDaoImpl extends BaseCacheDao<UserBean> {
}
