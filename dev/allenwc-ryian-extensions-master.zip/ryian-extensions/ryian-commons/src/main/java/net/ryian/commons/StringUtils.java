/**
 * 
 */
package net.ryian.commons;

/**
 * @author wangcheng
 *
 */
public class StringUtils extends org.apache.commons.lang3.StringUtils{

	
}
