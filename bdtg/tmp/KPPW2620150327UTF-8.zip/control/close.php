<?php 
defined ( 'IN_KEKE' ) or exit ( 'Access Denied' );
require keke_tpl_class::template('close');
die();