1. Use retrofit2 & dagger & okhttp3, preparing for server communication
