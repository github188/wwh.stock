insert into h2user(test_id, name, test_date, age, price, test_type, version) values (101,'Tomcat', '2017-1-1 1:1:1', 3, 9.99, 1, 1),
insert into h2user(test_id, name, test_date, age, price, test_type, version) values (102,'Jerry', '2017-3-1 1:1:1', 2, 19.99, 1, 2);
insert into h2user(test_id, name, test_date, age, price, test_type, version) values (103,'Bob', '2017-4-1 1:1:1', 13, 99.99, 1, 3);
insert into h2user(test_id, name, test_date, age, price, test_type, version) values (104,'Joe', '2017-2-1 1:1:1', 18, 1.99, 1, 4);
insert into h2user(test_id, name, test_date, age, price, test_type, version) values (105,'Tony', '2017-2-1 1:1:1', 18, 1.99, 1, 5);