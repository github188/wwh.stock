<?php 
echo '接受到数据：';
echo $_POST["name"].'<br>';
echo $_POST["cname"].'<br>';
echo $_POST["category_id"].'<br>';
echo $_POST["symbol"].'<br>';
echo $_POST["price"].'<br>';
echo $_POST["diff"].'<br>';
echo $_POST["chg"].'<br>';
echo $_POST["preclose"].'<br>';
echo $_POST["open"].'<br>';
echo $_POST["high"].'<br>';
echo $_POST["low"].'<br>';
echo $_POST["amplitude"].'<br>';
echo $_POST["volume"].'<br>';
echo $_POST["mktcap"].'<br>';
echo $_POST["pe"].'<br>';
echo $_POST["market"].'<br>';
echo $_POST["category_name"].'<br>';

?>