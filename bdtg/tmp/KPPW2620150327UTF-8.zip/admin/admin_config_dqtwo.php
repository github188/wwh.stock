<?php	defined ( 'ADMIN_KEKE' ) or exit ( 'Access Denied' );
$isShop12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='shop12'");
$isClose12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='close12'");
$isTask12=db_factory::get_one("select * from ".TABLEPRE."witkey_basic_config where k='task12'");
$objDistrict = keke_table_class::get_instance('witkey_district');
$url = 'index.php?do=config&view=dqtwo';
if($page){
	$page=$_R['page'];
	$url.='&page='.$page;
}else{
	$page=1;
}
if($_R['id']){
	$id=intval($_R[id]);
	$url.='&id='.$id;
}
$two=$objDistrict->get_grid('upid='.$id, $url,$page,10,' order by id desc');
if($_R['is_submit']==1){
	foreach($_R[id] as $key =>$val){
		$arrFields = array('name'=>$_R[nametwo][$key]);
		$arrWhere = array('id'=>$_R[id][$key]);
		$intResult = $objDistrict->save($arrFields,$arrWhere);
	}
		kekezu::admin_show_msg ( "修改成功", "index.php?do=config&view=dqtwo&page=".$page.'&id='.$_R['upid1'], 2, '', 'success' );
}else{
	require $template_obj->template(ADMIN_DIRECTORY.'/tpl/admin_config_' . $view );
}
if($_R[op]=='del'){
	$intResult = $objDistrict->del('id',$_R[id2]);
	kekezu::admin_show_msg ( "删除成功", "index.php?do=config&view=dqtwo&page=".$page.'&id='.$_R['id'], 2, '', 'success' );
}