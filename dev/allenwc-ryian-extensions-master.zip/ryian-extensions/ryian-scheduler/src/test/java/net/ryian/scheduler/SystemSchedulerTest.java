package net.ryian.scheduler;

public class SystemSchedulerTest {

	public static void main(String[] s) throws Exception {
		
		while(1>0) {
			Thread.sleep(10000);
		}
	}
	
}
